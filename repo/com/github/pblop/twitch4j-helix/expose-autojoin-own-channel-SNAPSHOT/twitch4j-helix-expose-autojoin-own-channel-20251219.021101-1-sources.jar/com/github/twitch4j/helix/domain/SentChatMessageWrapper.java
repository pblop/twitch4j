package com.github.twitch4j.helix.domain;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SentChatMessageWrapper extends ValueWrapper<SentChatMessage> {}
