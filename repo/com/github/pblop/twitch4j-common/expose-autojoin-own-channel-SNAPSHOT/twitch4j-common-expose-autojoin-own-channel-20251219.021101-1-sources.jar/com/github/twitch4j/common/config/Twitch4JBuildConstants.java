package com.github.twitch4j.common.config;

import java.lang.String;

final class Twitch4JBuildConstants {
  public static final String VERSION = "expose-autojoin-own-channel-SNAPSHOT";

  private Twitch4JBuildConstants() {
  }
}
